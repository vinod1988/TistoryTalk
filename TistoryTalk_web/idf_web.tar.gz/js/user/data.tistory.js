/**
 * 티스토리 oepnapi를 사용하기위해 랩핑 
 *   
 * @author 정민철
 * @see jquery
 * @see jquery.cookie
 * @version 1.0  
 * 
 * js 가 import곳의 URI에 #access_token= 값이 붙어있으면 
 * 알아서 쿠키정보를 얻고 정보도 체크한다.
 */
TISTORY_TALK = {
	//////////////////////////////////////////////
	// OAuth :  Consumer 에 등록된 정보
	// 관련값이 바뀌면 변경해야함.
	//////////////////////////////////////////////
		
	/***
	 * oAuth 에서 사용하는 클라이언트 아이디를 의미한다.
	 * @returns {String}
	 */	
	cliendId : function() {
		//return "6493acc2e5623c5b66defc190ed20dc0";
		return "e520c1662592514ef9d03f2faa064fb7";
	},
	
	/***
	 * oAuth 인증을 받기위한 callback 주소를 의미한다.
	 * @returns {String}
	 */
	redirectUri: function() {
		//return "http://localhost:8080/DevDay/auth.jsp";
		return "http://211.43.193.18/auth.jsp";
	},
		
	/**
	 * accesstoken을 알아낸다.
	 * init() 함수에서 쿠키에 accessToken에 대한 보장받는다. 
	 */
	accessToken :function() {
		return $.cookie('tistory_token');
	},
	
	
	/**
	 * OPEN-API를 요청한다.
	 * 
	 * crossdomain문제를 피하기위해 json_proxy.jsp?url= 의 파라미터로 URL값을 던져준다.
	 * 
	 * apiUrl 	: openapi url 						(예: https://www.tistory.com/apis/post/read)
	 * apiParam	: access_token을 제외한 파라미터값을 의미 	(예: targetUrl=tost&postId=1)
	 *  
	 * @see accessToken()
	 * 
	 * //var sample = TISTORY_TALK.getJson('https://www.tistory.com/apis/blog/info', null);
	 */
	getJson : function(apiUrl, apiParam) {
		var resultJson = null;		
		$.ajax({
		    type : "POST" 
		    , async : false 
		    , url : 'json_proxy.jsp'
		    , timeout : 30000 //제한시간 지정
		    , data : 'url=' + encodeURIComponent(this._apiUri(apiUrl, apiParam))
			, success : function(response, status, request) {
				if (typeof(response) == "object") {
					resultJson = response;
				}		    	
		    }
		});		
		return resultJson;
	},

	
	
	/////////////////////////////////////////////////////////////
	// 이 아래를 수정 불필요한 메소드들임.
	/////////////////////////////////////////////////////////////	
	/**
	 * targetURL을 가져온다. (단, 기본블로그 정보를 리턴)
	 * @returns
	 */
	targetUrl: function() { 
		var targetUrl = this.getMyInfo().secondaryUrl.replace('http://','');
		if (targetUrl==null || targetUrl.length <= 0 ) {
			targetUrl = this.getMyInfo().url.replace('http://','').replace('.tistory.com',''); 
		}	
		return targetUrl;
	},
	
	/**
	 * 내블로그 정보를 JSON으로 받는다 (단, 기본블로그 정보를 리턴)
	 * 
	 * @returns
	 * { 
	 * 	 status 		:	서버 응답 	예)200 : 성공, 기본적인 Http response code를 따름
	 *	,item			: 	각 블로그의 개별 블로그 노드 	복수개가 있을 수 있음
	 *	,url		 	:	블로그 기본 URL 	
	 *	,secondaryUrl	: 	블로그 2차 도메인 	
	 *	,nickname 		:	닉네임 	
	 *	,title 			:	블로그 타이틀 	
	 *	,description 	:	블로그 설명 	
	 *	,default 		:	대표 블로그 여부 	
	 *	,blogIconUrl 	:	블로그 아이콘 URL 	
	 *	,faviconUrl 	:	파비콘 URL 	
	 *	,profileThumbnailImageUrl	:	프로필 썸네일 이미지 URL 	
	 *	,profileImageUrl:	프로필 이미지 URL 	
	 *	,statistics		:	기본 통계 수치 부모 노드 	
	 *	,post 			:	글 수 	
	 *	,comment 		:	댓글 수 	
	 *	,trackback 		:	트랙백 수 	
	 *	,guestbook 		:	방명록 수 	
	 *	,invitation		:	초대 수
	 * }
	 */
	getMyInfo : function() {
		return MY_INFO;
	},
	
	/**
	 * 액서스 토큰관리와 기본정보를 가져온다. 
	 */
	init : function() {
		
		if (this.accessToken() == null) {
			if (this._findUriAccessToken()!=null){
				$.cookie('tistory_token', this._findUriAccessToken(), { expires: 1 });
			}else{
				document.location.href =  this._authUri();
			}
		}else{//액서스토큰이 있음.
			//기본 블로그 정보를 찾는다. 액서스 토큰이 맞는지 체크하는 용도도 같이 한다.
			var myinfo = this.getJson('https://www.tistory.com/apis/blog/info', null);
			if (typeof(myinfo.tistory.item) != "undefined") {
				$.each(myinfo.tistory.item ,function(idx, val) {  
					if ("Y" == eval("val.default")) {
						MY_INFO = val;
					}			
				});
			}else{
				$.cookie('tistory_token',null);
				alert('액서스토큰이 잘못되었거나, 기본블로그 정보를 찾을수 없습니다');
				document.location.href= this.redirectUri();
			}
		}
	},
	
	/////////////////////////////////////////////////////////////
	//
	// private
	//
	/////////////////////////////////////////////////////////////
	/***
	 * URI에서 엑서스 토큰값을 찾아본다.
	 * @returns {String}
	 */
	_findUriAccessToken: function() {
		var url = document.location.href;
		if (url.indexOf('#access_token=')>0) {
			return url.substr(url.indexOf('#access_token=') + '#access_token='.length, url.length);
		}else{
			return null;
		}
	},
	
	
	/***
	 * 인증을 받기위한 주소를 리턴한다.
	 * @returns {String}
	 */
	_authUri : function() {		
		return "https://www.tistory.com/oauth/authorize?client_id="+ this.cliendId()
				+ "&redirect_uri=" + this.redirectUri()
				+ "&response_type=token";
	},
	
	/***
	 * tistory에서 api용 URI을 만들때 사용한다.
	 * 
	 * @param apiUrl
	 * @param apiParam
	 * @returns {String}
	 */
	_apiUri : function(apiUrl, apiParam) {
		var base = apiUrl + '?access_token=' + this.accessToken();
		
		if (apiParam!=null && typeof(apiParam)=='string') {
			base += '&' + apiParam;
		}
		
		base += '&output=json';
		
		return base;
	}
	
};
TISTORY_TALK.init();