/**
* LIST VIEW를 컨트롤하는 기능을 한다.
* 작성자 : 정민철
*/
function CTR_LIST_VIEW(id) {
	this.listview_id = id;
}  
//jquery에서 접근하기위한  id값을 세팅한다
CTR_LIST_VIEW.prototype.id = function() {
	return "#"+this.listview_id;
}
//아이템하나를 추가한다
CTR_LIST_VIEW.prototype.add = function(text, link, clkHandler) {
	$(this.id()).append('<li><a href="'+link+'">'+text+'</a></li>');
	
	//클릭이벤트 추가
	if (clkHandler != null) {
		$(this.id()+">li:last-child").click(clkHandler);	
	}		
}
//추가한것을 반영한다.
CTR_LIST_VIEW.prototype.refresh = function() {
	$(this.id()).listview('refresh');
}
//마지막 노드를 제거한다.
CTR_LIST_VIEW.prototype.removeLast = function() {
	$(this.id()+">li:last-child").remove();
}
//특정 노드를 제거한다.
CTR_LIST_VIEW.prototype.remove = function(index) {
	if (typeof($(this.id()+">li")[index]) == "object") {
		$(this.id()+">li")[index].remove();
	}else{			
	}
}
//모든 노드를 제거한다.
CTR_LIST_VIEW.prototype.clear = function() {
	$(this.id()).empty();
}
//노드의 갯수를 리턴한다.
CTR_LIST_VIEW.prototype.count = function() {
	return $(this.id()).length;
}